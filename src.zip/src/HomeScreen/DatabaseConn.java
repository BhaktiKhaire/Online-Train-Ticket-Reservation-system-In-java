/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HomeScreen;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class DatabaseConn
{
    public static void main(String args[])
    {
        try
        {
            String url ="jdbc:mysql://localhost:3306/railwaysystem";
            String username="root";
            String password="";
            Connection temp=DriverManager.getConnection(url,username,password);
            
            System.out.println("Database connected Succesfully");
            Statement st = temp.createStatement();
            ResultSet rs = st.executeQuery("select*from adminlogin");
            while(rs.next()){
                System.out.println("username:"+rs.getString(1));
                System.out.println("password:"+rs.getString(2));
                
                
            }
        }
        catch(Exception obj)
        {
            System.out.println(obj);
        
        }
    }
}